# RGBIR Independent C/L implementation specification

- Read RGBIR_Independent_Class_Loc_Formal_Spec_20260907.md.
- C0 is the preserved OEv1 baseline; C1 is an unvalidated object/scale/class
  relative-logit candidate (not dense anchor-level classification imitation).
- L1 is standalone aligned DFL distribution KD; it requires external verified geometry.
- No C+L or learned routing is implemented in this package.
- reference_kernels.py contains isolated numerical kernels, not the project trainer.
- test_reference_kernels.py has 18 local CPU tests; kernel_test_results.json records
  their actual result. No server training, dataset inference, or geometry audit was run.
- The new specification supersedes future CL/CGT expansion strategy only. Do not
  alter or cancel active legacy experiments automatically.

Run: python -m pytest -q test_reference_kernels.py
